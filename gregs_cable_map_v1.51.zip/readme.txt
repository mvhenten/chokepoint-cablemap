Greg's Cable Map
================

This is the base data for Greg's Cable Map, in ArcGIS format.   It is released under 
the GPL; you're welcome to use it for personal/internal use, but not sell it for a
profit.  Under the GPL, any changes you make, you should feed back to the author.

http://www.cablemap.info

greg@cablemap.info

VERSION HISTORY

v1.0  09-Aug-2010  Initial Release